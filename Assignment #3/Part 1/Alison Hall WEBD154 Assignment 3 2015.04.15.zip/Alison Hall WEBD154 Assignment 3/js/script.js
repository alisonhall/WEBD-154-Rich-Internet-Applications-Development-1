Parse.initialize("S4KPo6rwBwk16fNnreLk1Px3vST6jRmDk6k9fs5R", "bXvGBcQE0WpWl8FaNLwgI0zv6iOkT6b0D3b3DlQq");

var usernameField = document.getElementById("usernameField");
var passwordField = document.getElementById("passwordField");
var loginButton   = document.getElementById("loginButton");
var signupButton  = document.getElementById("signupButton");
var loginBlock    = document.getElementById('login');
var welcomeBlock  = document.getElementById('welcomeMessage');
var welcomeText   = document.getElementById('message');
var myJournalsDiv = document.getElementById('myJournalsDiv');
var myEntriesDiv = document.getElementById('myEntriesDiv');
var newEntryDiv = document.getElementById('newEntryDiv');

loginButton.addEventListener('click', loginHandler);
signupButton.addEventListener('click', signupHandler);


var user = new Parse.User();

function loginHandler(){
	user.set("username", usernameField.value);
	user.set("password", passwordField.value);
	user.logIn({
		success:function (user){
			console.log("login worked");
			// loggedIn();
			hideLogin();
			var JournalData = Parse.Object.extend("Journals"); 
			var query = new Parse.Query(JournalData);
			var journalsRelation = user.relation("userJournals");
			journalsRelation.query().find({
				success: function (results){
					for (var i=0; i<results.length; i++){
						var journalData = results[i];
						var journal = new Journal (journalData);
					}
					buildNewJournalButton(journalData);
				},
				error:function(error){
					alert("Something went wrong: error is " + error.message);
				}
			});
		}, 
		error: function (user, error){
			console.log("error "+ error.code);
		}
	});
}

function signupHandler(){
	user.set("username", usernameField.value);
	user.set("password", passwordField.value);
	user.signUp(null, {
		success:function (user){
			console.log("signup worked");
			// loggedIn();
			hideLogin();
			var JournalData = Parse.Object.extend("Journals"); 
			var query = new Parse.Query(JournalData);
			var journalsRelation = user.relation("userJournals");
			journalsRelation.query().find({
				success: function (results){
					for (var i=0; i<results.length; i++){
						var journalData = results[i];
						var journal = new Journal (journalData);
					}
					buildNewJournalButton(journalData);
				},
				error:function(error){
					alert("Something went wrong: error is " + error.message);
				}
			});
		}, 
		error: function (user, error){
			console.log("error "+ error.code);
		}
	});
}

// function loggedIn(){
// 	hideLogin();
// 	var JournalData = Parse.Object.extend("Journals"); 
// 	var query = new Parse.Query(JournalData);
// 	var journalsRelation = user.relation("userJournals");
// 	journalsRelation.query().find({
// 		success: function (results){
// 			for (var i=0; i<results.length; i++){
// 				var journalData = results[i];
// 				var journal = new Journal (journalData);
// 			}
// 		},
// 		error:function(error){
// 			alert("Something went wrong: error is " + error.message);
// 		}
// 	});
// }

function hideLogin (){
	loginBlock.className = "hidden";
	welcomeMessage.className= "shown";
	welcomeText.textContent = "Welcome " + user.get("username");
}

function buildNewJournalButton(journalData){
	var button = document.createElement("button");
	var buttonLabel = document.createTextNode("Add Journal");
	button.appendChild(buttonLabel);
	button.addEventListener('click', function(event){
		//
		var journal = new Journal (journalData);
	});
	myJournalsDiv.appendChild(button);
}

function buildNewEntryButton(entriesData, self){
	var button = document.createElement("button");
	var buttonLabel = document.createTextNode("Add Entry");
	button.appendChild(buttonLabel);
	button.addEventListener('click', function(event){
		//
		var entry = new Entry (entriesData, self);
	});
	myEntriesDiv.appendChild(button);
}

var Journal = function(data){
	var self = this;
	self.data = data;
	self.entries = [];

	self.makeJournals = function(){
		self.journalTitle = document.createElement("button");
		var myJournals = self.data.get("journalTitle");
		var journalLabel = document.createTextNode(myJournals);
		self.journalTitle.appendChild(journalLabel);
		self.journalTitle.className = "journalTitle";
		self.journalTitle.addEventListener('click', self.findJournalEntries.bind(self));
		myJournalsDiv.appendChild(self.journalTitle);
	}

	self.findJournalEntries = function(){
		console.log("Clicked journal: " + self.journalTitle.innerText);
		myEntriesDiv.innerHTML = "";
		var EntriesData = Parse.Object.extend("Entries");
		var query = new Parse.Query(EntriesData);
		var entriesRelation = self.data.relation("userEntries");
		entriesRelation.query().find({
			success: function (results){
				console.log("entriesRelation query success");
				for (var i=0; i<results.length; i++){
					var entriesData = results[i];
					self.entries.push(entriesData);
					var entry = new Entry (entriesData, self);
				}
				buildNewEntryButton(entriesData, self);
			},
			error: function(error){
				alert("Something went wrong: error is " + error.message);
			}
		});
	}

	self.makeJournals();

}



var Entry = function(data, journalSelf){
	var self = this;
	self.data = data;
	self.entries = [];

	self.createEntries = function(entriesData){
		console.log("createEntries function start");
		self.entryTitle = document.createElement("button");
		var myEntries = entriesData.attributes.entryTitle;
		var entryLabel = document.createTextNode(myEntries);
		self.entryTitle.appendChild(entryLabel);
		self.entryTitle.className = "entryTitle";
		myEntriesDiv.appendChild(self.entryTitle);
		self.entryTitle.addEventListener('click', function(event){
			self.buildEditEntry(myEntries, entriesData);
		});
	}

	self.buildEditEntry = function(myEntries, entriesData){
		console.log("buildNewEntry function start");
		newEntryDiv.innerHTML = "";
		self.entryTitle = myEntries;
		self.entryText = entriesData.attributes.entryText;

		self.entryTitleInput = document.createElement("input");
		self.entryTitleInput.value = self.entryTitle;
		self.entryTextInput = document.createElement("textarea");
		self.entryTextInput.value = self.entryText;
		var saveButton = document.createElement("button");
		var saveLabel = document.createTextNode("Save");
		saveButton.appendChild(saveLabel);
		saveButton.className = "saveButton";

		saveButton.addEventListener('click', function(event){
			self.saveEntry(self.entryTitle, self.entryTitleInput.value, self.entryTextInput.value, entriesData, journalSelf);
		});

		newEntryDiv.appendChild(self.entryTitleInput);
		newEntryDiv.appendChild(self.entryTextInput);
		newEntryDiv.appendChild(saveButton);
	}

	self.saveEntry = function(oldTitle, newTitle, newText, entriesData, journalSelf){
		console.log("saveEntry function start");

		var EntriesData = Parse.Object.extend("Entries");
		var entriesRelation = journalSelf.data.relation("userEntries");
		entriesRelation.query().find({
			success: function (results){
				console.log("entriesRelation query success");
				for (var i=0; i<results.length; i++){
					var entriesData = results[i];					
					if(entriesData.attributes.entryTitle == oldTitle){
						entriesData.set("entryTitle", newTitle);
						entriesData.set("entryText", newText);
						entriesData.save();
						alert("Saved!");
					}
				}	
			},
			error: function(error){
				alert("Something went wrong: error is " + error.message);
			}
		});
	}

	self.createEntries(self.data);
}















